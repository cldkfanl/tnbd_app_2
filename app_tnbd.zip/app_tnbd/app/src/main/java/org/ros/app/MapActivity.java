package org.ros.app;

public class MapActivity {
}
