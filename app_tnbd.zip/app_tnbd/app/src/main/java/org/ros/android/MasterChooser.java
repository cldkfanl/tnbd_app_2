package org.ros.android;

public class MasterChooser {
}
