package org.ros.android;

public class BitmapFromCompressedImage {
}
