package org.ros.android;

public class BitmapFromImage {
}
