package org.ros.android;

public class AppCompatRosActivity {
}
