package org.ros.android;

public interface MessageCallable {
}
